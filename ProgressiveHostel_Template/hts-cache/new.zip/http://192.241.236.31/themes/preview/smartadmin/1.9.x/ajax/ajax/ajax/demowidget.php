<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
<html><head>
<title>404 Not Found</title>
</head><body>
<h1>Not Found</h1>
<p>The requested URL /themes/preview/smartadmin/1.9.x/ajax/ajax/ajax/demowidget.php was not found on this server.</p>
<hr>
<address>Apache/2.2.22 (Ubuntu) Server at 192.241.236.31 Port 80</address>
</body></html>
